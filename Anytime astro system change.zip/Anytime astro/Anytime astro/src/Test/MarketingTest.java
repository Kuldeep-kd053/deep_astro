package Test;

public class MarketingTest {
}
