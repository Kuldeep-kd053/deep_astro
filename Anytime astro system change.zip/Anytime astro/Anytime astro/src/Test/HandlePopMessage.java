package Test;

import org.openqa.selenium.By;

import java.awt.*;
import java.awt.event.InputEvent;

public class HandlePopMessage extends LaunchBrowserPage{

    public static void alert_handle() throws AWTException, InterruptedException {
        driver.switchTo().alert().dismiss();
        driver.switchTo().alert().accept();
        driver.switchTo().alert().getText();
        driver.switchTo().alert().sendKeys("accept");

        driver.findElement(By.id("PopUp")).click(); // Clicking on the popup button
        Robot robot = new Robot();
        robot.mouseMove(300,450);
        // Navigating through mouse hover. Note that the coordinates might differ, kindly check the coordinates of x and y axis and update it accordingly.
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        Thread.sleep(2000);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        Thread.sleep(2000);
    }

}
