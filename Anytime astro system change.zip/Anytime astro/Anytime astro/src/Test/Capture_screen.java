package Test;

import Test.LaunchBrowserPage;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

import java.io.File;
import java.io.IOException;
import java.util.Random;


public class Capture_screen extends LaunchBrowserPage {

    public static void take_screenshot(String order_id) throws IOException {
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshot, new File("D:\\Yammy_" + order_id +".jpg"));


    }
    public static void take_general_screenshot() throws IOException {
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshot, new File("D:\\ERROR" +".jpg"));


    }
}

