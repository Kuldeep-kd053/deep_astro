package Test;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ScrollPage extends LaunchBrowserPage{
    @FindBy(how = How.CLASS_NAME, using = "goxjub")
    public static WebElement search;
    @FindBy(how = How.XPATH, using = "(//img[@class='hCL kVc L4E MIw'])[3]")
    public static WebElement Waste;
    @FindBy(how = How.XPATH, using = "(//div[@class='ujU zI7 iyn Hsu'])[1]")
    public static WebElement Kam;
    //mouse hover
    public static void mouse_hover(WebElement voicesearch){
        Actions action = new Actions(driver);
        action.moveToElement(voicesearch).build().perform();
    }
    // Double click
    public static void double_click(WebElement imageSearch){
        Actions actions = new Actions(driver);
        actions.doubleClick(imageSearch);
    }
    public static void click_and_hold(WebElement element) throws InterruptedException {
        driver.get("https://www.bitdriverupdater.com/");
        Actions actions = new Actions(driver);
        //move to element
        actions.moveToElement(search);
        Thread.sleep(6000);
        // Call clickAndHold() method to perform click and hold operation.
        actions.clickAndHold().perform();
        Thread.sleep(6000);
    }
    public static void drag_drop(WebElement drag, WebElement drop) throws InterruptedException {
        driver.get("https://www.pinterest.com/linimg/drag-and-drop-ui/");
        Actions action = new Actions(driver);
        action.dragAndDrop(Waste, Kam).build().perform();
    }
}


