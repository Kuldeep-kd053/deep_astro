package Test;

import Pages.PujaPurchasePage;
import org.bouncycastle.oer.its.ieee1609dot2.basetypes.SequenceOfUint8;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static Pages.PujaAdminPage.handleAlert;
import static Pages.PujaPurchasePage.*;
import static Test.Capture_screen.take_general_screenshot;
import static Test.Capture_screen.take_screenshot;


public class PujaPurchaseTest extends LaunchBrowserPage {
    @FindBy(how = How.XPATH, using = "//div[@class='text-center ']")
    public static List<WebElement> ProductList;
    @FindBy(how = How.XPATH, using = "//p[@class='fw-bold mb-0 text-black']")
    public static List<WebElement> product;

    @FindBy(how = How.XPATH, using = "//a[@class='page-link']//span[contains(text(),'Next')]")
    public static WebElement next_page;

    @Test(priority = 1, invocationCount = 1)
    public static void puja_purchase_inr() throws InterruptedException, IOException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        //all_puja_list();
        driver.get(Puja_URL_test);
        //leave page pop up handle if occurs
        handleAlert();
        driver.navigate().refresh();
        // open one puja details page
        select_puja();
        navigate_checkout();
        // check out page user details
        checkout_user_details_in("kuldeep kumar", " ", "07877784366", "deep@tafmail.com");
        // click on pay now button
        paynow.click();
        //switch_razorpay_window
        switch_window_razorpay();
        // try up to 3 times go find elements
        razorpayoption();
        switch_success_Page_main_window();
        get_payment_id_success_page();
        Thread.sleep(1000);
        String order_id_success_page = pay_id.getText();
        take_screenshot(order_id_success_page);
        ((JavascriptExecutor) driver).executeScript("window.open()");
        // Get all window handles
        List<String> tabs = new ArrayList<>(driver.getWindowHandles());
        // Switch to the new tab
        driver.switchTo().window(tabs.get(1));
        admin_login();
        puja_report();
        Order_search.sendKeys(order_id_success_page);
        button_search_button.click();
        String order_id = admin_get_order_id.getText();
        String new_order = order_id.substring(1, order_id.length() - 1);
        System.out.println("order id on admin :" + new_order);
        Assert.assertEquals(new_order, order_id_success_page, "oder not found on admin, 'try again'");
    }

    @Test
    public static void puja_purchase_USD() throws InterruptedException, IOException {
        // use us ip to do payment in us
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        //all_puja_list();
        driver.get(Puja_URL_test);
        //leave page pop up handle if occurs
        handleAlert();
        driver.navigate().refresh();
        // open one puja details page
        select_puja();
        navigate_checkout();
        // check out page user details
        checkout_user_details_in("kuldeep kumar", " ", "2025961737", "deep@tafmail.com");
        stripe_details("4242 4242 4242 4242", "12/26", "123");
        Thread.sleep(2000);
        login_paynow.click();
        Thread.sleep(20000);
        try {
            if (intent_error.isDisplayed()) {
                take_general_screenshot();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(" we are good to go");
        }
        //switch_success_Page_main_window();
        get_payment_id_success_page();
        Thread.sleep(1000);
        String order_id_success_page = pay_id.getText();
        take_general_screenshot();
        take_screenshot(order_id_success_page);
        ((JavascriptExecutor) driver).executeScript("window.open()");
        // Get all window handles
        List<String> tabs = new ArrayList<>(driver.getWindowHandles());
        // Switch to the new tab
        driver.switchTo().window(tabs.get(1));
        admin_login();
        puja_report();
        Order_search.sendKeys(order_id_success_page);
        button_search_button.click();
        String order_id = admin_get_order_id.getText();
        String new_order = order_id.substring(1, order_id.length() - 1);
        System.out.println("order id on admin :" + new_order);
        Assert.assertEquals(new_order, order_id_success_page, "oder not found on admin, 'try again'");

    }


    @Test(priority = 2)
    public static void print_all_puja_list() throws InterruptedException {
        driver.get(Puja_URL_test);
        all_puja_list();

    }

    @Test(priority = 3, invocationCount = 1)
    public static void navigate_to_check_out_Page_live() throws InterruptedException, IOException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        //open puja url
        driver.get(Puja_Live_URL);
        //leave page pop up handle if occurs
        handleAlert();
        driver.navigate().refresh();
        // open one puja details page
        select_puja();
        try {
            puja_details_page.isDisplayed();
        } catch (NoSuchElementException e) {
            System.out.println("puja page doesn't open, again trying to open it" + e.getMessage());
            select_puja();
        } catch (ElementClickInterceptedException e) {
            System.out.println("puja page doesn't open, again trying to open it" + e.getMessage());
        }
        navigate_checkout();
        // check out page user details
        checkout_user_details_in("kuldeep", "kumar", "7877784366", "kuldeep@innovanathinklabs.com");
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2)); // Timeout after 10 seconds
            wait.until(ExpectedConditions.elementToBeClickable(paynow));
            paynow.click();
        } catch (ElementNotInteractableException e) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
            // click on element
            paynow.click();
            // click on pay now button
        }
        try {
            // Find the iframe containing the Razorpay popup
            WebElement iframe = driver.findElement(By.xpath("//iframe[@class='razorpay-checkout-frame']"));
            // Switch to the iframe(razor pay tab)
            driver.switchTo().frame(iframe);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Get handles of all open windows
        Set<String> windowHandles = driver.getWindowHandles();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        //        // switch back to main window
        driver.switchTo().window(tabs.get(0));
    }

    @Test(priority = 4, invocationCount = 1)
    public static void all_puja_url() throws InterruptedException, IOException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        driver.get("https://otest.anytimeastro.com/puja/products/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        all_puja_url_list();
    }

    @Test
    public static void puja_purchase_login_us() throws InterruptedException, IOException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        loginus("johnfrida306@gmail.com", "1234");
        Thread.sleep(3000);
        select_puja();
        navigate_checkout();
        // check out page user details
        checkout_user_details_in("kuldeep kumar", " ", "8548545125", "deep@tafmail.com");
        String total_checkout_page = total_price_checkout_page.getText();
        System.out.println("checkout page total price: " + total_checkout_page);
        Thread.sleep(2000);
        // click on pay now button
        login_paynow.click();
        stripe_details("4242424242424242", "0426", "321");
        Thread.sleep(3000);
        login_proceed.click();
        Thread.sleep(20000);
        //switch_success_Page_main_window();
        get_payment_id_success_page();
        Thread.sleep(1000);
        String order_id_success_page = pay_id.getText();
        String total_price_thank_you_Page = thank_you_page_price.getText();
        String total_price_thank_you_Page1 = total_price_thank_you_Page.replace("$","");
        System.out.println("Thank you page total price: " + total_price_thank_you_Page1);
        take_screenshot(order_id_success_page);
        ((JavascriptExecutor) driver).executeScript("window.open()");
        // Get all window handles
        List<String> tabs = new ArrayList<>(driver.getWindowHandles());
        // Switch to the new tab
        driver.switchTo().window(tabs.get(1));
        admin_login();
        puja_report();
        Order_search.sendKeys(order_id_success_page);
        button_search_button.click();
        String order_id = admin_get_order_id.getText();
        String new_order = order_id.substring(1, order_id.length() - 1);
        System.out.println("order id on admin :" + new_order);
        Assert.assertEquals(new_order, order_id_success_page, "oder not found on admin, 'try again'");
        Assert.assertEquals(total_checkout_page,total_price_thank_you_Page1, "price difference");
    }

    @Test
    public static void puja_purchase_login_india() throws InterruptedException, IOException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        login_in("7877784366", "1234");
        Thread.sleep(3000);
        select_puja();
        navigate_checkout();
        // check out page user details
        checkout_user_details_in("kuldeep kumar", " ", "8548545125", "deep@tafmail.com");
        String total_checkout_page = total_price_checkout_page.getText();
        System.out.println("checkout page total price: " + total_checkout_page);
        // click on pay now button
        paynow.click();
        login_proceed.click();
        //switch_razorpay_window
        switch_window_razorpay();
        Thread.sleep(3000);
        upi_id.sendKeys("test@ibl");
        // try up to 3 times go find elements
        //razorpayoption();
        verify_pay.click();
        Thread.sleep(10000);
        switch_success_Page_main_window();
        get_payment_id_success_page();
        String total_price_thank_you_Page = thank_you_page_price.getText();
        String total_price_thank_you_Page1 = total_price_thank_you_Page.replace("₹","");
        System.out.println("Thank you page total price: " + total_price_thank_you_Page1);
        Thread.sleep(1000);
        String order_id_success_page = pay_id.getText();
        take_screenshot(order_id_success_page);
        ((JavascriptExecutor) driver).executeScript("window.open()");
        // Get all window handles
        List<String> tabs = new ArrayList<>(driver.getWindowHandles());
        // Switch to the new tab
        driver.switchTo().window(tabs.get(1));
        admin_login();
        puja_report();
        Order_search.sendKeys(order_id_success_page);
        button_search_button.click();
        String order_id = admin_get_order_id.getText();
        String new_order = order_id.substring(1, order_id.length() - 1);
        System.out.println("order id on admin :" + new_order);
        //Assert.assertEquals(new_order, order_id_success_page, "oder not found on admin, 'try again'");
        //Assert.assertEquals(driver.getTitle(), "Wrong Title");
        Assert.assertEquals(total_checkout_page,total_price_thank_you_Page1,"price difference");
    }
}

