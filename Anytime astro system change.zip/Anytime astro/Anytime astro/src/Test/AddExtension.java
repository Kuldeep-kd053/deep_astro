package Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import javax.swing.plaf.synth.SynthTextAreaUI;
import java.io.File;

import static org.openqa.selenium.remote.DesiredCapabilities.*;

public class AddExtension extends LaunchBrowserPage{
    @Test
    public static void run() {
        WebDriverManager.chromedriver().setup();
        System.setProperty("webdriver.chdrome.driver","C:/Users/kuldeep/Downloads/chromedriver_win32.exe");
      // DesiredCapabilities capabilities = DesiredCapabilities.chrome();
        ChromeDriverService service = new ChromeDriverService.Builder()

                .usingDriverExecutable(new File("/usr/local/chromedriver"))
                .usingAnyFreePort()
                .build();
        ChromeOptions options = new ChromeOptions();
        //options.merge(capabilities);
        ChromeDriver driver = new ChromeDriver(service, options);
        options.addExtensions (new File("C:/Users/kuldeep/Downloads/webguardplus_1.0.7.crx"));
        driver.get("https://www.tutorialspoint.com/index.html");
    }
}

