package Test;


import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;
public class TestReportTest {

//    public static void Ankit(){
//        System.out.println("hello");
//    }
        public static void main(String[] args) {
            // Code to execute your Selenium test cases

            // Generate test report (replace this with TestNG or JUnit report generation code)
            String testReport = "<html><body><h1>Test Report</h1><p>Your test report content here</p></body></html>";

            // Send email with the test report attached
            sendEmailWithReport(testReport);
        }

        public static void sendEmailWithReport(String testReport) {
            // Sender's email ID and password
            String senderEmail = "kuldeep@innovanathinklabs.com";
            String senderPassword = "Kuldeep@54321";

            // Receiver's email ID
            String receiverEmail = "kuldeep@innovanathinklabs.com";

            // Setup mail server properties
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.example.com");
            props.put("mail.smtp.port", "587");

            // Get the Session object
            Session session = Session.getInstance(props,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(senderEmail, senderPassword);
                        }
                    });

            try {
                // Create a default MimeMessage object
                Message message = new MimeMessage(session);

                // Set From: header field
                message.setFrom(new InternetAddress(senderEmail));

                // Set To: header field
                message.setRecipients(Message.RecipientType.TO,
                        InternetAddress.parse(receiverEmail));

                // Set Subject: header field
                message.setSubject("Test Report");

                // Create MimeBodyPart object and set your HTML content
                MimeBodyPart mimeBodyPart = new MimeBodyPart();
                mimeBodyPart.setContent(testReport, "text/html");

                // Create Multipart object and add MimeBodyPart objects to it
                Multipart multipart = new MimeMultipart();
                multipart.addBodyPart(mimeBodyPart);

                // Set the multipart object to the message
                message.setContent(multipart);

                // Send message
                Transport.send(message);

                System.out.println("Test report sent successfully.");

            } catch (MessagingException e) {
                throw new RuntimeException(e);
            }
        }
    }


