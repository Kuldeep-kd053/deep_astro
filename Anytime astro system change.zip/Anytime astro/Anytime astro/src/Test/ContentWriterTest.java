package Test;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static Pages.ContentWriterPage.*;
import static Test.ScrollPage.Kam;
import static Test.ScrollPage.mouse_hover;

public class ContentWriterTest extends LaunchBrowserPage{
    @Test
    public void verify_ContentWriter_permission() throws InterruptedException {
        user_login(Content_writer_name, Content_writer_pass);
        user_avtar.click();
        String user_name = username.getText();
        System.out.println(user_name + " this is the text which is fetched by logged user");
        Thread.sleep(7000);
        Assert.assertEquals(user_name, Content_writer_name);
        System.out.println("user login : Hello test user login is successful");

        List<String> all_elements_text = new ArrayList<>();

        for (WebElement webElement : permission_list) {
            all_elements_text.add(webElement.getText());
        }

        String[] str = new String[all_elements_text.size()];

        for (int i = 0; i < all_elements_text.size(); i++) {
            str[i] = all_elements_text.get(i);
        }

//        if (str.length == Content_writer_per_list.length)
//            System.out.println("permission matched: "+str.length);
//        else System.out.println("given permissions doesn't match: "+ Content_writer_per_list.length);

        if(Arrays.toString(str).equals(Arrays.toString(Content_writer_per_list)))

            System.out.println("verified given permission: "+str.length);
        else
            System.out.println("not verified given permission: "+ Content_writer_per_list.length);
        Assert.assertEquals(str.length, Content_writer_per_list.length,"problem with admin user permission");

    }
    @Test
public static void mouse_effect(){
    mouse_hover(Kam);
}

    }



