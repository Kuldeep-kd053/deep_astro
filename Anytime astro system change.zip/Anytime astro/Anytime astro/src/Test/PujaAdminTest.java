package Test;

import Pages.PujaAdminPage;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import static Pages.PujaAdminPage.puja_Purchase;
import static Pages.PujaAdminPage.puja_purchase;

public class PujaAdminTest extends LaunchBrowserPage{
    @Test
    public static void open_puja_page() throws InterruptedException {
        PujaAdminPage pujaAdminPage = PageFactory.initElements(driver, PujaAdminPage.class);
        driver.get(Login_page_url);
        user_login("kuldeep@innovanathinklabs.com", "0");
        Thread.sleep(8000);
        user_avtar.click();
        System.out.println(" user logged in ");
        System.out.println(puja_Purchase.getText());
        puja_purchase();

    }
}