//package Test;
//
//import Pages.PujaPurchasePage;
//import io.github.bonigarcia.wdm.WebDriverManager;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.openqa.selenium.*;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.PageFactory;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.annotations.Test;
//import java.io.File;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.time.Duration;
//import java.util.List;
//
//import static Pages.PujaPurchasePage.next;
//
//public class ExcelDataRead extends LaunchBrowserPage {
//    @Test
//    public static void read_excel() {
//        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
//        try {
//            // Find elements containing puja names and URLs
//            List<WebElement> pujaNames = driver.findElements(By.xpath("//p[@class='fw-bold mb-0 text-black']"));
//            List<WebElement> pujaUrls = driver.findElements(By.xpath("//a[@class='p-3 pb-0']"));
//
//            // Create a new Excel workbook and sheet
//            Workbook workbook = new XSSFWorkbook();
//            Sheet sheet = workbook.createSheet("Puja List");
//
//            // Write the header row
//            Row header = sheet.createRow(0);
//            header.createCell(0).setCellValue("Puja Name");
//            header.createCell(1).setCellValue("Puja URL");
//
//            // Write data to the sheet
//            for (int i = 0; i < pujaNames.size() && i < 150; i++) {
//                String pujaName = pujaNames.get(i).getText();
//                String pujaURL = pujaUrls.get(i).getAttribute("href");
//                int puja_url_number = pujaNames.size();
//                if (puja_url_number % 50 == 0) {
//                    try {
//                        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(2));
//                        wait1.until(ExpectedConditions.elementToBeClickable(next));
//                        next.click();
//                    } catch (ElementNotInteractableException e) {
//                        JavascriptExecutor js = (JavascriptExecutor) driver;
//                        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
//                        next.click();
//                        // recursive method call
//                        read_excel();
//                    }
//                }
//                Row row = sheet.createRow(i + 1);
//                row.createCell(0).setCellValue(pujaName);
//                row.createCell(1).setCellValue(pujaURL);
//            }
//
//            // Specify the directory and file name
//            File outputDir = new File("output");
//            if (!outputDir.exists()) {
//                outputDir.mkdirs(); // Create the directory if it does not exist
//            }
//            File file = new File(outputDir, "puja_list.xlsx");
//
//            // Write the output to a file
//            try (FileOutputStream fileOut = new FileOutputStream(file)) {
//                workbook.write(fileOut);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//
//            // Close the workbook
//            workbook.close();
//            // Print the absolute path of the file
//            System.out.println("Excel file created at: " + file.getAbsolutePath());
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // Close the WebDriver
//            System.out.println("wow wow wow");
//        }
//    }
//}


package Test;
import Pages.PujaPurchasePage;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import static Pages.PujaPurchasePage.next;

public class ExcelRead extends LaunchBrowserPage {

    @Test
    public static void read_excel() {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        try {
            // Create a new Excel workbook and sheet
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Puja List");

            // Write the header row
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Puja Name");
            header.createCell(1).setCellValue("Puja URL");

            int rowIndex = 1;
            while (rowIndex <= 133) {
                try {
                    // Find elements containing puja names and URLs
                    List<WebElement> pujaNames = driver.findElements(By.xpath("//p[@class='fw-bold mb-0 text-black']"));
                    List<WebElement> pujaUrls = driver.findElements(By.xpath("//a[@class='p-3 pb-0']"));

                    for (int i = 0; i < pujaNames.size() && rowIndex <= 133; i++, rowIndex++) {
                        String pujaName = pujaNames.get(i).getText();
                        String pujaURL = pujaUrls.get(i).getAttribute("href");

                        Row row = sheet.createRow(rowIndex);
                        row.createCell(0).setCellValue(pujaName);
                        row.createCell(1).setCellValue(pujaURL);
                    }
                    if (rowIndex > 133) break;

                    try {
                        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
                        wait1.until(ExpectedConditions.elementToBeClickable(next));
                        next.click();
                    } catch (ElementNotInteractableException e) {
                        JavascriptExecutor js = (JavascriptExecutor) driver;
                        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                        next.click();
                    }

                } catch (StaleElementReferenceException e) {
                    // Re-find elements if they become stale
                    System.out.println("Stale element reference, retrying...");
                }
            }

            // Specify the directory and file name
            File outputDir = new File("output");
            if (!outputDir.exists()) {
                outputDir.mkdirs(); // Create the directory if it does not exist
            }
            File file = new File(outputDir, "puja_list.xlsx");

            // Write the output to a file
            try (FileOutputStream fileOut = new FileOutputStream(file)) {
                workbook.write(fileOut);
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Close the workbook
            workbook.close();
            // Print the absolute path of the file
            System.out.println("Excel file created at: " + file.getAbsolutePath());

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the WebDriver
            driver.quit();
        }
    }
}
