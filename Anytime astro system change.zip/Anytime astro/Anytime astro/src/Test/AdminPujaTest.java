package Test;

import Pages.PujaPurchasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

import static Pages.PujaPurchasePage.*;

public class AdminPujaTest extends LaunchBrowserPage {
    @Test(priority = 1)
    public static void create_puja() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        //admin_login();
        item_master_list();
        Select_Puja_Type("Individual");
        select_category("Radha Mohan Puja");
        enter_item_master_name("Test automation kumar singh");
        Thread.sleep(3000);
        if (is_variant_available.isSelected()) {
            System.out.println("shipping selected");
        } else {
            is_variant_available.click();
            System.out.println("shipping choosen");
        }
        add.click();
        try {
            if (creation_error_message.isDisplayed()) {
                System.out.println("category isn't created : Something went wrong while Adding Category category, category already exists");
            } else {
                System.out.println("category created successfully");
            }
        } catch (NoSuchElementException e) {
            System.out.println("Element not found: " + e.getMessage());
        }

    }

    //@Test(priority = 2)
    public static void add_multiple_variants_test() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        //admin_login();
        item_master_list();
        search_puja("Test automation kumar singh");
        view_edit_variant.click();
        add_multiple_variants();

    }


    @Test(priority = 3)
    public static void edit_price() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
        //admin_login();
        item_master_list();
        search_puja("Test automation kumar singh");
        view_edit_variant.click();
        item_variant_price();
    }

    @Test(priority = 4)
    public static void edit_puja_variant_test() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        //admin_login();
        item_master_list();
        edit_puja_variant();
    }

    @Test(priority = 5)
    public static void edit_default_variant_test() {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        //admin_login();
        item_master_list();
        search_puja("Jai Bhole Puja");
        edit_default_variant();
    }

    @Test(priority = 6)
    public static void publish_puja() {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        //admin_login();
        item_master_list();
        search_puja("Test automation kumar singh");
        if (Objects.equals(is_active.getText(), "true")) {
            System.out.println("puja already published");
        } else publish_puja.click();
        driver.switchTo().alert().accept();
    }

    @Test(priority = 7)
    public static void create_puja_category() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        //admin_login();
        try{
        open_mater_category();
        } catch (Exception e) {
            System.out.println("koi mil gya");
        }
        Select_Puja_Type("Individual");
        category_name.sendKeys("Puja new category12345678");
        image.sendKeys("C://Users//kuldeep//Downloads//lord-shiva-holiday-maha-shivratri//442.jpg");
        add.click();
        Thread.sleep(10000);
//        try {
//            if (success_message.isDisplayed()) {
//                System.out.println("success message category: " + success_message.getText());
//            } else if (creation_error_message.isDisplayed()) {
//                System.out.println("error message category :" + creation_error_message.getText());
//            }
//        } catch (NoSuchElementException e) {
//            System.out.println("Element not found: " + e.getMessage());
//        }
    }

    @Test(priority = 8)
    public static void Create_category_alias() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        //admin_login();
        open_master_category_alias();
        select_category("Deep Test Category");
        category_alias_name.sendKeys("Puja New Category Alias1");
        add.click();
//        try {
//            if (success_message.isDisplayed()) {
//                System.out.println("success message category alias : " + success_message.getText());
//            } else if (creation_error_message.isDisplayed()) {
//                System.out.println("error message category alias :" + creation_error_message.getText());
//            }
//        } catch (NoSuchElementException e) {
//            System.out.println("Element not found: " + e.getMessage());
//        }
    }

    @Test(priority = 9)
    public static void create_variant() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        //admin_login();
        open_master_variant();
        variant_name.sendKeys("new variant1");
        image.sendKeys("C://Users//kuldeep//Downloads//lord-shiva-holiday-maha-shivratri//442.jpg");
        add.click();
//        try {
//            if (success_message.isDisplayed()) {
//                System.out.println("success message variant : " + success_message.getText());
//            } else if (creation_error_message.isDisplayed()) {
//                System.out.println("error message variant :" + creation_error_message.getText());
//            }
//        } catch (NoSuchElementException e) {
//            System.out.println("Element not found: " + e.getMessage());
//        }
    }

    @Test(priority = 10)
    public static void create_variant_alias() throws InterruptedException {
        PujaPurchasePage pujaPurchasePage = PageFactory.initElements(driver, PujaPurchasePage.class);
        //admin_login();
        try{
        open_master_variant_alias();
        } catch (Exception e) {
            System.out.println("koi fir se mil gya");
        }
        Select dropdown = new Select(select_variant);
        dropdown.selectByVisibleText("Beej Mantra");
        // Select an option by visible text
        variant_name_alias.sendKeys("Variant alias new");
        add.click();
//        try {
//            if (success_message.isDisplayed()) {
//                System.out.println("success message variant alias: " + success_message.getText());
//            } else if (creation_error_message.isDisplayed()) {
//                System.out.println("error message variant alias:" + creation_error_message.getText());
//            }
//        } catch (NoSuchElementException e) {
//            System.out.println("Element not found: " + e.getMessage());
//        }
    }
}
