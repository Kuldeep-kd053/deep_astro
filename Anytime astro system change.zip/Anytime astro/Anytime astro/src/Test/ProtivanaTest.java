package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;


public class ProtivanaTest extends LaunchBrowserPage {

    public static String Url = "http://test.protivana.com/";
    @FindBy(how = How.ID, using = "chocolateflavors")
    public static WebElement add_to_cart;
    @FindBy(how = How.ID, using = "addCart")
    public static WebElement addCart;
    @FindBy(how = How.ID, using = "floatingemail")
    public static WebElement Email;
    @FindBy(how = How.NAME, using = "fname")
    public static WebElement fName;
    @FindBy(how = How.NAME, using = "flastname")
    public static WebElement lName;
    @FindBy(how = How.NAME, using = "faddress")
    public static WebElement address;

    @FindBy(how = How.XPATH, using = "//select[@id='floatingSelectState']//option")
    public static WebElement state;
    @FindBy(how = How.XPATH, using = "//select[@id='floatingSelectCity']//option")
    public static WebElement city;
    @FindBy(how = How.ID, using = "floatingzip")
    public static WebElement zipCode;
    @FindBy(how = How.NAME, using = "fnumber")
    public static WebElement number;
    @FindBy(how = How.ID, using = "payNow")
    public static WebElement paynow;
    @FindBy(how = How.ID, using = "floatingSelectState")
    public static WebElement select_state;
    @FindBy(how = How.ID, using = "floatingSelectCity")
    public static WebElement select_city;
// Select state_dropdown = new Select(state);
// Select city_prodown = new Select(city);
   @FindBy(how = How.XPATH, using = "//div[@class='row align-items-center']//h2")
   public static WebElement scroll_To;


    @Test(priority = 1)
    public static void brow(){
     driver.get(Url);
 }

    @Test(priority = 2)
    public static void protein() throws InterruptedException {
        Thread.sleep(6000);
//        JavascriptExecutor je = (JavascriptExecutor) driver;
//        je.executeScript("arguments[0].scrollIntoView(true);",   scroll_To);
        WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(2));
       wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='saveitems']//p")));
       //wait3.until(ExpectedConditions.visibilityOf(scroll_To));

        System.out.println(scroll_To.getText());
        add_to_cart.click();
        addCart.click();
        Email.sendKeys("kuldeep@innovanathinklabs.com");
        fName.sendKeys("kuldeep");
        lName.sendKeys("singh");
        address.sendKeys("jaipur ,Rajasthan");
        Thread.sleep(3000);
        WebElement dropdownState = state; // Change the locator strategy as needed

        // Create a Select object to interact with the dropdown
        Select dropdown = new Select(dropdownState);

        // Get the selected option
        WebElement selectedOption = dropdown.getFirstSelectedOption();

        // Get the text of the selected option
        String selectedText = selectedOption.getText();
        System.out.println(selectedText);

        select_state.click();
        Thread.sleep(3000);
        state.getAttribute("Rajasthan");
        state.click();
        select_city.click();
        city.getAttribute("Jhunjhunūn");
        //zipCode.sendKeys("302017");
        number.sendKeys("7877784366");
        paynow.click();
        Thread.sleep(3000);

    }
}

