package Pages;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.List;




public class BrokenLinks extends Landing_Page {
    //static WebDriver driver;

    @Test
    public static void url4() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

        driver.get("https://www.mpanchang.com/");
Thread.sleep(3000);
driver.switchTo().alert();

//        Thread.sleep(10000);
//// Finding all the available links on webpage
//        List<WebElement> sub_links = driver.findElements(By.tagName("a"));
//        List<WebElement> Bread_crumb_links = driver.findElements(By.xpath("//ul[@class='nav navbar-nav MenuSeprationDownloadRightBorder menu-width']//li[@class='dropdown fsat_menu ']//li"));
//        System.out.println("number of links: " + sub_links.size());
//
//// Iterating each link and checking the response status
//        for (WebElement link : Bread_crumb_links) {
//            String url = link.getAttribute("href");
//            verifyLink(url);
//            System.out.println("bread crumb url:" + url);
//            for (WebElement link2 : sub_links) {
//                String url2 = link2.getAttribute("href");
//                System.out.println(url2);
//            }
//
//        }


//    public static void verifyLink(String url) throws IOException {
////        try {
//            URL link = new URL(url);
//            HttpURLConnection httpURLConnection = (HttpURLConnection) link.openConnection();
//            httpURLConnection.setConnectTimeout(5000); // Set connection timeout to 3 seconds
//            httpURLConnection.connect();
//
//
//            if (httpURLConnection.getResponseCode() == 200) {
//                System.out.println(url + " - " + httpURLConnection.getResponseMessage());
//            } else {
//                System.out.println(url + " - " + httpURLConnection.getResponseMessage() + " - " + "is a broken link");
//            }
//        } catch (Exception e) {
//            System.out.println(url + " - " + "is a broken link");
//
//        }
//


            //Launching sample website

//            driver.manage().window().maximize();
////
//            //Get list of web-elements with tagName  - a
//            List<WebElement> allLinks = driver.findElements(By.tagName("a"));
//
//            //Traversing through the list and printing its text along with link address
//            for (WebElement link : allLinks) {
//
//                System.out.println(link.getText() + " - " + link.getAttribute("href"));
//            }
//
//            System.out.println("total number of URLs:" + allLinks.size());
//            //Commenting driver.quit() for user to easily verify the links
//            //driver.quit();
//        }


//        public static void urls () {
//
//            driver.get("https://www.mpanchang.com/");
//            driver.switchTo().alert().dismiss();
//        List <WebElement> links = driver.findElements(By.tagName("a"));
//        int linkCount=links.size();
//        System.out.println("Total number of page on the webpage:"+ linkCount);
//        String[] texts=new String[linkCount];
//        int t=0;
//        for (WebElement text:links){
//            texts[t]=text.getText();//extract text from link and put in Array
//            //System.out.println(texts[t]);
//            t++;
//        }
//        for (String clicks:texts) {
//
//            driver.findElement(By.linkText(clicks)).click();
//            if (driver.getTitle().equals("notWorkingUrlTitle" )) {
//                System.out.println("\"" + t + "\""
//                        + " is not working.");
//            } else {
//                System.out.println("\"" + t + "\""
//                        + " is working.");
//            }
//
//            driver.navigate().back();
        }}


