package Pages;
import Test.LaunchBrowserPage;
import org.testng.annotations.Test;

public class Login_Test extends LaunchBrowserPage {
    @Test
    public static void loginTest() throws InterruptedException {
        user_login("kuldeep@innovanathinklabs.com","0");
        Thread.sleep(8000);
        user_avtar.click();
        System.out.println(" user loged in ");

    }

}
