package Pages;


import com.sun.jdi.ThreadGroupReference;
import org.apache.logging.log4j.message.ThreadDumpMessage;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;

import static Test.LaunchBrowserPage.driver;


public class PujaPurchasePage {
    public static String Puja_URL_test = "https://otest.anytimeastro.com/puja/products/";

    public static String Puja_Live_URL = "https://www.anytimeastro.com/puja/products/";
    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Choose Options')]")
    public static List<WebElement> choose_option;
    @FindBy(how = How.XPATH, using = "//div[contains(text(),'Add to Cart')]")
    public static List<WebElement> list_add_to_cart;

    @FindBy(how = How.LINK_TEXT, using = "href")
    public static List<WebElement> puja_urls;
    @FindBy(how = How.ID, using = "paynow")
    public static WebElement paynow;


    @FindBy(how = How.ID, using = "stripesubmitbtn")
    public static WebElement login_paynow;
    @FindBy(how = How.XPATH, using = "//div[@class='alert alert-danger alert-dismissible fade show']")
    public static WebElement intent_error;


    @FindBy(how = How.ID, using = "proceedbtn")
    public static WebElement login_proceed;

    @FindBy(how = How.XPATH, using = "//input[@name='vpa']")
    public static WebElement upi_id;

    @FindBy(how = How.NAME, using = "button")
    public static WebElement verify_pay;


    @FindBy(how = How.ID, using = "addcart")
    public static WebElement add_to_cart;
    @FindBy(how = How.XPATH, using = "//div[@class='offcanvas-bottom-body']//a")
    public static WebElement check_out;
    @FindBy(how = How.ID, using = "fname")
    public static WebElement name;
    @FindBy(how = How.ID, using = "lname")
    public static WebElement last_name;

    @FindBy(how = How.NAME, using = "phone")
    public static WebElement Phone;
    @FindBy(how = How.ID, using = "Email")
    public static WebElement email;
    @FindBy(how = How.ID, using = "INR")
    public static WebElement inr;
    @FindBy(how = How.ID, using = "USD")
    public static WebElement USD;

    @FindBy(how = How.XPATH, using = "//div[@class='product-detail bg-white py-4']")
    public static WebElement puja_details_page;

    @FindBy(how = How.XPATH, using = "//span[contains(text(),'Next')]")
    public static WebElement next;
    @FindBy(how = How.XPATH, using = "(//div[@class='flex items-center justify-between'])[2]")
    public static WebElement phone_pe;
    @FindBy(how = How.XPATH, using = "//div[@id='modal-inner']//div[@class='svelte-30hv15']")
    public static WebElement click_on_wallet;
    @FindBy(how = How.XPATH, using = "//p[@class='fw-bold mb-0 text-black']")
    public static List<WebElement> add_choose;
    @FindBy(how = How.XPATH, using = "//a[@class='p-3 pb-0']")
    public static List<WebElement> puja_url;

    @FindBy(how = How.XPATH, using = "//div[@role='alert']")
    public static WebElement alert_message;

    @FindBy(how = How.XPATH, using = "(//div[@data-value='wallet'])[2]")
    public static WebElement razorpay_wallet;
    @FindBy(how = How.XPATH, using = "  (//form[@method='post']//button)[1]")
    public static WebElement success_button;

    @FindBy(how = How.XPATH, using = "//p[@class='font-14 mb-0']/b")
    public static WebElement pay_id;

    @FindBy(how = How.XPATH, using = "//h1[@class='success-color fw-bold font-24']//span")
    public static WebElement thank_you_page_price;



    public static List<String> all_elements_text = new ArrayList<>();
    // admin panel
    @FindBy(how = How.NAME, using = "Email")
    public static WebElement admin_username;
    @FindBy(how = How.NAME, using = "Passwrd")
    public static WebElement admin_pass;
    @FindBy(how = How.XPATH, using = "//button[contains(text(),'Sign In')]")
    public static WebElement admin_sign_in;
    @FindBy(how = How.XPATH, using = "(//span[@class='text-blue'])[3]")
    public static WebElement admin_get_order_id;
    @FindBy(how = How.XPATH, using = "(//tr[@role='row']//td)[5]")
    public static List<WebElement> user_mail_on_admin;
    @FindBy(how = How.XPATH, using = "//tbody//tr[@role='row'']")
    public static List<WebElement> order_list_admin;
    @FindBy(how = How.ID, using = "OrderSearch")
    public static WebElement Order_search;
    @FindBy(how = How.ID, using = "btnSearch")
    public static WebElement button_search_button;
    @FindBy(how = How.XPATH, using = "(//ul[@style='display: block;']//a)[1]")
    public static WebElement master_category;
    @FindBy(how = How.XPATH, using = "(//ul[@style='display: block;']//a)[2]")
    public static WebElement master_category_alias;
    @FindBy(how = How.XPATH, using = "(//ul[@style='display: block;']//a)[3]")
    public static WebElement mater_variant;
    @FindBy(how = How.XPATH, using = "(//ul[@style='display: block;']//a)[4]")
    public static WebElement mater_variant_alias;


    @FindBy(how = How.ID, using = "PujaTypeId")
    public static WebElement category_type_drop_down;
    @FindBy(how = How.ID, using = "cat_name")
    public static WebElement category_name;
    @FindBy(how = How.ID, using = "CategoryAliasName")
    public static WebElement category_alias_name;
    @FindBy(how = How.ID, using = "var_name")
    public static WebElement variant_name;
    @FindBy(how = How.XPATH, using = "//input[@id='VariantAliasName']")
    public static WebElement variant_name_alias;

    @FindBy(how = How.XPATH, using = "//div[@id='apiResponseDisplay']//h4")
    public static WebElement creation_error_message;
    @FindBy(how = How.XPATH, using = "//div[@id='apiResponseDisplay']")
    public static WebElement success_message;


    @FindBy(how = How.ID, using = "CurrencyId")
    public static WebElement currency_dropdown;
    @FindBy(how = How.ID, using = "baseAmt")
    public static WebElement base_amount;
    @FindBy(how = How.ID, using = "netAmt")
    public static WebElement net_amount;
    @FindBy(how = How.ID, using = "discount")
    public static WebElement discount_amount;


    @FindBy(how = How.ID, using = "item_master_name")
    public static WebElement item_master_name;
    @FindBy(how = How.ID, using = "btnSubmit")
    public static WebElement add;
    @FindBy(how = How.ID, using = "IsVariantAvailble")
    public static WebElement is_variant_available;


    @FindBy(how = How.ID, using = "imgUrl")
    public static WebElement choose_image;

    @FindBy(how = How.XPATH, using = "//span[contains(text(),'Master')]")
    public static WebElement master;
    @FindBy(how = How.XPATH, using = "//a[contains(text(),' Item Master')]")
    public static WebElement item_master;
    @FindBy(how = How.ID, using = "CategoryId")
    public static WebElement select_category;
    @FindBy(how = How.ID, using = "item_master_name")
    public static WebElement Enter_Item_Master_Name;


    @FindBy(how = How.XPATH, using = "//input[@type='search']")
    public static WebElement puja_search;

    @FindBy(how = How.XPATH, using = "//a[contains(text(),'View/Edit Variants')]")
    public static WebElement view_edit_variant;

    @FindBy(how = How.NAME, using = "VariantId")
    public static WebElement select_variant;
    @FindBy(how = How.XPATH, using = "//a[contains(text(),'View/Edit Detail')]")
    public static List<WebElement> view_edit_detail;


    @FindBy(how = How.XPATH, using = "//input[@value='Edit']")
    public static WebElement edit_item_variant;

    @FindBy(how = How.ID, using = "title")
    public static WebElement puja_title;
    @FindBy(how = How.ID, using = "Badgedescription")
    public static WebElement badge_description;
    @FindBy(how = How.CLASS_NAME, using = "(note-editable")
    public static WebElement short_description;
    @FindBy(how = How.CLASS_NAME, using = "note-editable")
    public static WebElement long_description;
    @FindBy(how = How.CLASS_NAME, using = "note-editable")
    public static WebElement mobile_description;
    @FindBy(how = How.XPATH, using = "//div[@class='spinner']")
    public static WebElement loader;


    @FindBy(how = How.XPATH, using = "//input[@value='Edit']")
    public static WebElement edit;

    @FindBy(how = How.ID, using = "imgUrl")
    public static WebElement image;

    @FindBy(how = How.ID, using = "mobimgUrl")
    public static WebElement mobile_image;
    @FindBy(how = How.ID, using = "item_order")
    public static WebElement item_order;
    @FindBy(how = How.ID, using = "isShipping")
    public static WebElement is_shipping;
    @FindBy(how = How.ID, using = "isFree")
    public static WebElement is_free;
    @FindBy(how = How.ID, using = "rating")
    public static WebElement rating;
    @FindBy(how = How.ID, using = "fake_sold")
    public static WebElement fake_sold;


    public static String puja_image_path = "/C://Users//kuldeep//Downloads//happy-ganesh-chaturthi-traditional-greeting-card-background//2642.jpg";


    @FindBy(how = How.XPATH, using = " //i[@class='fa fa-book']")
    public static WebElement admin_report_option;
    @FindBy(how = How.XPATH, using = "//ul[@class='treeview-menu menu-open']")
    public static WebElement admin_order_list;
    public static String Puja_admin_URL = "https://pujatestadmin.anytimeastro.com/";
    //view/ edit price
    @FindBy(how = How.XPATH, using = "//a[contains(text(),'View/Edit Price')]")
    public static List<WebElement> view_edit_price;
    @FindBy(how = How.XPATH, using = "//input[@value='Publish']")
    public static WebElement publish_puja;
    @FindBy(how = How.XPATH, using = "(//tr[@class='odd']//td)[5]")
    public static WebElement is_active;
    @FindBy(how = How.ID, using = "pujaNameTitle")
    public static WebElement puja_title_name;
    @FindBy(how = How.ID, using = "usericon")
    public static WebElement user_icon;
    @FindBy(how = How.XPATH, using = "//a[contains(text(),'Login_Via_Email')]")
    public static WebElement login_via_mail;
    @FindBy(how = How.ID, using = "UserEmail")
    public static WebElement user_mail;

    @FindBy(how = How.ID, using = "ContactMobile")
    public static WebElement mobile_number;
    @FindBy(how = How.ID, using = "getOtp")
    public static WebElement mobile_otp;
    @FindBy(how = How.ID, using = "orderAmt")
    public static WebElement total_price_checkout_page;


    @FindBy(how = How.ID, using = "getemailOtp")
    public static WebElement get_otp;
    @FindBy(how = How.ID, using = "EmailOtp1")
    public static WebElement enter_otp;
    @FindBy(how = How.ID, using = "Otp1")
    public static WebElement enter_mob_otp;


    @FindBy(how = How.ID, using = "btnEmailVerify")
    public static WebElement mail_submit;
    @FindBy(how = How.ID, using = "btnVerify")
    public static WebElement phone_submit;

    @FindBy(how = How.ID, using = "wzrk-cancel")
    public static WebElement notification;


    @FindBy(how = How.XPATH, using = "//iframe[@title='Secure card number input frame']")
    public static WebElement enter_card_number;

    @FindBy(how = How.XPATH, using = "(//iframe[@role='presentation'])[2]")
    public static WebElement card_date;
    @FindBy(how = How.XPATH, using = "(//iframe[@allow='payment *'])[3]")
    public static WebElement card_cvv;


    static List<String> all_puja_list = new ArrayList<>();
    static List<String> all_puja_url_list = new ArrayList<>();
    static List<WebElement> anchorElements = driver.findElements(By.tagName("a"));


    // user login
    public static void loginus(String mail, String otp) throws InterruptedException {
        user_icon.click();
        Thread.sleep(2000);
        notification.click();
        login_via_mail.click();
        Thread.sleep(2000);
        user_mail.sendKeys(mail);
        Thread.sleep(2000);
        get_otp.click();
        Thread.sleep(2000);
        enter_otp.sendKeys(otp);
        Thread.sleep(2000);
        mail_submit.click();
    }

    public static void login_in(String mobile, String otp) throws InterruptedException {
        user_icon.click();
        Thread.sleep(2000);
        notification.click();
        Thread.sleep(2000);
        mobile_number.sendKeys(mobile);
        Thread.sleep(2000);
        mobile_otp.click();
        Thread.sleep(2000);
        enter_mob_otp.sendKeys(otp);
        Thread.sleep(2000);
        phone_submit.click();
    }

    public static void open_mater_category() {
        master.click();
        master_category.click();

    }

    public static void open_master_category_alias() {
        master.click();
        master_category_alias.click();
    }

    public static void open_master_variant() {
        master.click();
        mater_variant.click();
    }

    public static void open_master_variant_alias() {
        master.click();
        mater_variant_alias.click();
    }

    public static void navigate_checkout() {
        try {
            add_to_cart.click();
        } catch (Exception e) {
            e.printStackTrace();
        }
        check_out.click();
    }

    public static void checkout_user_details_in(String fname, String lname, String number, String mail) {
        name.sendKeys(fname);
        last_name.sendKeys(lname);
        Phone.sendKeys(number);
        email.sendKeys(mail);
    }

    public static void stripe_details(String card_number, String date, String cvv) throws InterruptedException {
        enter_card_number.sendKeys(card_number);
        Thread.sleep(3000);
        card_date.click();
        card_date.sendKeys(date);
        card_cvv.click();
        card_cvv.sendKeys(cvv);
        Thread.sleep(3000);
    }

    public static void all_puja_name_with_options() {
        for (WebElement element : choose_option) {
            all_elements_text.add(element.getText());
        }
        for (WebElement addtocart : list_add_to_cart) {
            all_elements_text.add(addtocart.getText());
        }
    }

    public static void select_puja() throws InterruptedException {
        int puja_number3 = Math.min(50, add_choose.size());
        Random random = new Random();
        int randomProduct = random.nextInt(puja_number3);
        WebElement randomElement = add_choose.get(randomProduct);

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2)); // Timeout after 10 seconds
            wait.until(ExpectedConditions.elementToBeClickable(randomElement));
            randomElement.click();
        } catch (ElementNotInteractableException e) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
            // click on element
            randomElement.click();
        }

        try {
            puja_details_page.isDisplayed();
        } catch (NoSuchElementException e) {
            System.out.println("puja page doesn't open, again trying to open it" + e.getMessage());
            select_puja();
        } catch (ElementClickInterceptedException e) {
            System.out.println("puja page doesn't open, again trying to open it" + e.getMessage());
        }
    }

    public static void admin_login() {
        driver.get(Puja_admin_URL);
        admin_username.sendKeys("admin@gmail.com");
        admin_pass.sendKeys("123456");
        admin_sign_in.click();
    }

    public static void puja_report() {
        admin_report_option.click();
        admin_order_list.click();
        admin_get_order_id.getText();
    }

    public static void switch_window_razorpay() {
        try {
            // Find the iframe containing the Razorpay popup
            WebElement iframe = driver.findElement(By.xpath("//iframe[@class='razorpay-checkout-frame']"));
            // Switch to the iframe(razor pay tab)
            driver.switchTo().frame(iframe);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void switch_window_stripe() {
        try {
            // Find the iframe containing the Razorpay popup
            WebElement iframe = driver.findElement(By.xpath("//iframe[@class='razorpay-checkout-frame']"));
            // Switch to the iframe(razor pay tab)
            driver.switchTo().frame(iframe);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void razorpayoption() {
        for (int i = 0; i < 3; i++) {
            try {
                Thread.sleep(1000);
                //click_on_wallet.click();
                //phone_pe.click();
                razorpay_wallet.click();
                break; // break loop if element found
            } catch (NoSuchElementException | InterruptedException e) {
                System.out.println("Attempt " + (i + 1) + ": Element not found yet, retrying...");
            }
        }
    }

    public static void switch_success_Page_main_window() {
        Set<String> windowHandles = driver.getWindowHandles();
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());

        // Switch to the new window
        for (String windowHandle : windowHandles) {
            if (!windowHandle.equals(driver.getWindowHandle())) {
                // switch to success/failed page
                driver.switchTo().window(windowHandle);
            }
        }
        // try up to 3 times go find elements
        for (int j = 0; j < 3; j++) {
            try {
                Thread.sleep(2000);
                success_button.click();
                break; // break loop if element found
            } catch (NoSuchElementException | InterruptedException e) {
                System.out.println("Attempt " + (j + 1) + ": Element not found yet, retrying...");
                // You can optionally wait a bit before retrying
                try {
                    Thread.sleep(2000); // Wait for 2 seconds before retrying
                } catch (InterruptedException ignored) {
                }
            }
        }
        // switch back to main window
        driver.switchTo().window(tabs.get(0));
        // try up to 3 times go find elements
    }

    public static void get_payment_id_success_page() {
        for (int k = 0; k < 3; k++) {
            try {
                System.out.println("Payment ID: " + pay_id.getText());
                break; // break loop if element found
            } catch (NoSuchElementException e) {
                System.out.println("Attempt " + (k + 1) + ": Element not found yet, retrying...");
            }
        }
    }


    public static void item_master_list() {
        master.click();
        item_master.click();
    }

    public static void Select_Puja_Type(String type) {
        Select dropdown = new Select(category_type_drop_down);
        // Select an option by visible text
        dropdown.selectByVisibleText(type);
    }

    public static void select_currency_type() throws InterruptedException {
        Select dropdown = new Select(currency_dropdown);
        // Select an option by visible text
        List<WebElement> options = dropdown.getOptions();
        // Iterate through each option and select it one by one
        for (int i = 1; i < options.size(); i++) {
            WebElement option = options.get(i);
            // Select the option
            dropdown.selectByVisibleText(option.getText());
            System.out.println("dropdown currency name: " + i + " " + option.getText());
            base_amount.sendKeys("100");
            discount_amount.sendKeys("10");
            net_amount.sendKeys("50");
            add.click();
        }
        driver.navigate().back();
        Thread.sleep(3000);
    }


    public static void all_puja_url_list() throws InterruptedException {
        System.out.println("number of puja urls on puja page: " + puja_url.size());
        int puja_url_number = puja_url.size();
        for (WebElement element : puja_url) {
            String url = element.getAttribute("href");
            all_puja_url_list.add(url);
        }
        if (puja_url_number % 50 == 0) {
            try {
                WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(2)); // Timeout after 10 seconds
                wait1.until(ExpectedConditions.elementToBeClickable(next));
                next.click();
            } catch (ElementNotInteractableException e) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                next.click();
                // recursive method call
                all_puja_url_list();
            }
            System.out.println(all_puja_url_list);
        }
    }


    public static void all_puja_list() throws InterruptedException {
        System.out.println("number of puja on puja page: " + add_choose.size());
        int puja_number = add_choose.size();
        for (int z = 0; z < puja_number; z++) {
            try {
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2));
                wait.until(ExpectedConditions.elementToBeClickable(add_choose.get(z)));
                all_puja_list.add(add_choose.get(z).getText());
            } catch (ElementNotInteractableException e1) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                add_choose.get(z).click();
                all_puja_list.add(add_choose.get(z).getText());
            }
        }
        if (puja_number % 50 == 0) {
            try {
                WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(2)); // Timeout after 10 seconds
                wait1.until(ExpectedConditions.elementToBeClickable(next));
                next.click();
            } catch (ElementNotInteractableException e) {
                //System.out.println("Element is not interactable: " + e.getMessage());
                //Perform alternative action, such as scrolling the page
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
                next.click();
                // recursive method call
                all_puja_list();
            }
            System.out.println(all_puja_list);
        }
    }

    public static void select_category(String category_name) {
        Select dropdown1 = new Select(select_category);
        // Select an option by visible text
        dropdown1.selectByVisibleText(category_name);
    }

    public static void enter_item_master_name(String item_name) {
        Enter_Item_Master_Name.sendKeys(item_name);
    }

    public static void create_puja() {
        admin_login();
        item_master_list();
        Select_Puja_Type("Individual");
        select_category("Deep Test Category");
        enter_item_master_name("wow");
        add.click();
    }

    public static void search_puja(String puja_name) {
        puja_search.sendKeys(puja_name);

    }

    public static void edit_puja_variant() throws InterruptedException {
        search_puja("Test automation kumar singh");
        view_edit_variant.click();
        for (int j = 0; j < view_edit_detail.size(); j++) {
            view_edit_detail.get(j).click();
            puja_title.click();
            puja_title.clear();
            puja_title.sendKeys("Test automation kumar singh");
            badge_description.clear();
            badge_description.sendKeys(" Ganpati and Mahadev puja");
            try {
                String description = "Your content goes here";  // Replace with data.result.description
                // Locate the Summernote editor (if necessary)
                WebElement short_description = driver.findElement(By.xpath("(//div[@class='note-editable'])[1]"));
                // Use JavascriptExecutor to execute the jQuery code
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("$('#longDescription1').summernote('code', arguments[0]);", description);
                //short_description.click();
                short_description.sendKeys(" Experienced Pandits");
                // driver.switchTo().defaultContent();
            } catch (java.util.NoSuchElementException e) {
                System.out.println(" Element not found.");
            }

            try {
                String description = "Your content goes here";  // Replace with data.result.description
                // Locate the Summernote editor (if necessary)
                WebElement long_description = driver.findElement(By.xpath("(//div[@class='note-editable'])[2]"));
                // Use JavascriptExecutor to execute the jQuery code
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("$('#longDescription1').summernote('code', arguments[0]);", description);
                //short_description.click();
                long_description.click();
                long_description.sendKeys(" Performing Aparajita Puja is considered auspicious ");
            } catch (java.util.NoSuchElementException e) {
                System.out.println("Element not found.");
            }
            try {
                String description = "Your content goes here";  // Replace with data.result.description
                // Locate the Summernote editor (if necessary)
                WebElement mobile_description = driver.findElement(By.xpath("(//div[@class='note-editable'])[3]"));
                // Use JavascriptExecutor to execute the jQuery code
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("$('#longDescription1').summernote('code', arguments[0]);", description);
                //short_description.click();
                mobile_description.sendKeys(" Performing Aparajita Puja ");
            } catch (java.util.NoSuchElementException e) {
                System.out.println("element not found");
            }
            add.click();
            driver.navigate().back();
        }
    }

    public static void item_variant_price() throws InterruptedException {
        for (int i = 0; i < view_edit_price.size(); i++) {
            view_edit_price = driver.findElements(By.xpath("//a[contains(text(),'View/Edit Price')]"));
            view_edit_price.get(i).click();
            select_currency_type();
        }
    }

    public static void edit_default_variant() {
        view_edit_variant.click();
        edit.click();
        image.sendKeys("C://Users//kuldeep//Downloads//lord-shiva-holiday-maha-shivratri//442.jpg");
        mobile_image.sendKeys("C://Users//kuldeep//Downloads//lord-shiva-holiday-maha-shivratri//442.jpg");
        item_order.sendKeys("1");
        is_shipping.click();
        //is_free.click();
        rating.sendKeys("4.5");
        fake_sold.sendKeys("10");
        add.click();
        driver.navigate().back();
    }


//    public static void add_multiple_variants1() throws InterruptedException {
//        try {
//            Select dropdown = new Select(select_variant);
//            // Select an option by visible text
//            List<WebElement> options = dropdown.getOptions();
//            // Iterate through each option and select it one by one
//            for (int i = 1; i < options.size(); i++) {
//                driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
//                dropdown.selectByIndex(i);;
//                //edit.click();
//                //image.sendKeys("C://Users//kuldeep//Downloads//lord-shiva-holiday-maha-shivratri//442.jpg");
//                //mobile_image.sendKeys("C://Users//kuldeep//Downloads//lord-shiva-holiday-maha-shivratri//442.jpg");
//                image.sendKeys("C://Users//kuldeep//Downloads//rama-character-with-arrow-bow//2582513.jpg");
//                mobile_image.sendKeys("C://Users//kuldeep//Downloads//rama-character-with-arrow-bow//2582513.jpg");
//                item_order.sendKeys("1");
//                if (is_shipping.isEnabled()) {
//                    is_shipping.click();
//                } else {
//                    System.out.println("shipping already enabled");
//                }
//                // is_free.click();
//                rating.sendKeys("4.5");
//                fake_sold.sendKeys("10");
//                add.click();
//            }
//        } catch (StaleElementReferenceException e) {
//            System.out.println("Oho");
//            add_multiple_variants();
//        }
//
//    }

    public static void add_multiple_variants() throws InterruptedException {
        try {
            Select dropdown = new Select(select_variant);
            // Select an option by visible text
            List<WebElement> options = dropdown.getOptions();
            // Iterate through each option and select it one by one
            for (int i = 1; i < options.size(); i++) {
                driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
//                WebElement option = options.get(i);
//                dropdown.selectByVisibleText(option.getText());
//                System.out.println("dropdown currency name: " + i + " " + option.getText());
                dropdown.selectByIndex(i);
                //edit.click();
                image.sendKeys("C://Users//kuldeep//Downloads//lord-shiva-holiday-maha-shivratri//442.jpg");
                mobile_image.sendKeys("C://Users//kuldeep//Downloads//lord-shiva-holiday-maha-shivratri//442.jpg");
                item_order.sendKeys("1");
                if (is_shipping.isEnabled()) {
                    is_shipping.click();
                } else {
                    System.out.println("shipping already enabled");
                }
                // is_free.click();
                rating.sendKeys("4.5");
                fake_sold.sendKeys("10");
                add.click();
                Thread.sleep(30000);
//                try {
//                    if (creation_error_message.isDisplayed()) {
//                        System.out.println("variant not created : Something went wrong while Adding variant., variant already exist");
//                    } else {
//                        System.out.println("variant created successfully");
//                    }
//                } catch (java.util.NoSuchElementException e) {
//                    System.out.println("Element not found: " + e.getMessage());
//                }
            }
        } catch (StaleElementReferenceException e) {
            System.out.println("Oho");
            add_multiple_variants();

        }

    }
}
