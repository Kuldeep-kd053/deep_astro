package Pages;

import org.openqa.selenium.WebDriver;

public class ExpertManagerPage {
    WebDriver driver;
    public ExpertManagerPage(WebDriver driver) {
        this.driver = driver;
    }
    public static String ExpertManager_name = "expertmanger@malinator.com";
    public static String ExpertManager_pass = "0";
    public static String[] ExpertManager_per_list = {"Home", "Experts", "Expert Profiles", "Registrations", "Chat Reviews",
            "Chat Report", "Attendance Report", "Account deletion Request", "Psychic Calls", "Chat Invite Summary"
            ,"Customer Spam Report", "Missed Chat Report", "Psychic Profile Review", "Expert Performance", "Notice Board",
            "Notice Board List", "Occasion", "Welcome Message Request", "Update Bank-Detail", "Bank-Detail List",
            "Expert Insights Summary", "Live Session Report"};
}
