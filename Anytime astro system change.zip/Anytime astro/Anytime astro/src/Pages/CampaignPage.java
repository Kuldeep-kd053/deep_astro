package Pages;

import org.openqa.selenium.WebDriver;

public class CampaignPage {
   WebDriver driver;
    public CampaignPage(WebDriver driver) {
        this.driver = driver;
    }


    public static String Campaign_name = "campaigntest@malinator.com";
    public static String Campaign_pass = "0";
    public static String[] Campaign_per_list  = {"Home", "First Purchase Report", "Call Chat Report",
            "Payments", "Registration"};
}
