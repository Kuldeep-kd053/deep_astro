import java.io.File;
import java.io.IOException;
import java.sql.Array;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.File;
import java.util.Scanner;


// press shift twice to open the search everywhere dialog and type `show whitespaces`,
// then press enter. you can now see whitespace characters in your code.
public class Main {


    public static void main(String[] args) {
        String day = "sunday";
        switch (day){
            case "sunday":
                System.out.println("today is HOLIDAY : "+ day);
                break;
            case "monday":
                System.out.println("today is : " + day);
                break;
            case "tuesday":
                System.out.println("Today is  :"+ day);
                break;
            default:
                System.out.println(day);
        }
        // get class loader type method
        Class c=Main.class;
        System.out.println("class loader file type: "+ c.getClassLoader());
        Pattern pattern = Pattern.compile("kuldeep", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher("kuldeep W3Schools!");
        boolean matchFound = matcher.find();
        if (matchFound) {
            System.out.println("Match found");
        } else {
            System.out.println("Match not found");
        }

        File myObj = new File("filename.txt");
        if (myObj.delete()) {
            System.out.println("Deleted the file: " + myObj.getName());
        } else {
            System.out.println("File not found at given location, Failed to delete the file.");
        }
        if (myObj.exists()) {
            System.out.println("aage aage");
        } else {
            System.out.println(":");
        }
        try {
            File myObj1 = new File("filename.txt");
            if (myObj1.createNewFile()) {
                System.out.println("File created: " + myObj1.getName());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        File myObj2 = new File("filename.txt");
        if (myObj2.exists()) {
            System.out.println("File name: " + myObj2.getName());
            System.out.println("Absolute path: " + myObj2.getAbsolutePath());
            System.out.println("Writeable: " + myObj2.canWrite());
            System.out.println("Readable: " + myObj2.canRead());
            System.out.println("File size in bytes: " + myObj2.length());
        } else {
            System.out.println("The file does not exist.");
        }
        int number = 100;
        for (int j = 1; j <= number; j++) {
//            if (j % 2 != 0) {
//                System.out.println(j);
//            } else {
//                System.out.println(j);
//            }
            System.out.println(j);
        }
        String str = "kuldeep", rst = "";
        char ch;
        for (int i = 0; i < str.length(); i++) {
            ch = str.charAt(i);
            rst = ch + rst ;
        }
        System.out.println("Reverse name : " + rst);
    }

}


